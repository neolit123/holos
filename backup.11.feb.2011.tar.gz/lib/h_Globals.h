#ifndef h_Globals_included
#define h_Globals_included
//----------------------------------------------------------------------

#ifdef H_WIN32

  #include <windows.h>
  static HINSTANCE static_WinInstance = H_NULL;

#endif

//----------------------------------------------------------------------
#endif
